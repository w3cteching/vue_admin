<template>
    <div>
       <h2>角色列表</h2> 
    </div>
</template>
<script>
export default {
    name:'rolelist'
}
</script>

<style lang="scss">
    
</style>